#!/usr/bin/env bash
# Faz uma chamada à API de homolog e mostra requisição, status, headers e corpo da resposta.
# O token é colocado automaticamente (e nunca é exibido).
#
# Uso:
#   scripts/api_request.sh [opções] MÉTODO ROTA [arquivo_corpo.json]
#
# Opções (antes do método):
#   --sem-token        não envia autenticação (testar 401)
#   --token VALOR      envia este token no lugar do token do Bran (testar token inválido)
#   -H "Nome: valor"   cabeçalho extra (pode repetir)
#
# Exemplos:
#   scripts/api_request.sh GET /reservas/123
#   scripts/api_request.sh POST /reservas evidencias/CT01_corpo.json
#   scripts/api_request.sh --sem-token GET /reservas/123
#
# ROTA pode ser só o caminho (/reservas) ou uma URL completa (https://...).
# Se a resposta for 401 com o token do Bran, renova o token UMA vez e repete.
set -euo pipefail
source "$(dirname "$0")/_load_env.sh"

auth_mode="auto"; custom_token=""; extra=()
while [[ $# -gt 0 ]]; do
  case "$1" in
    --sem-token) auth_mode="none"; shift ;;
    --token)     auth_mode="custom"; custom_token="${2:-}"; shift 2 ;;
    -H)          extra+=(-H "$2"); shift 2 ;;
    *) break ;;
  esac
done

if [[ $# -lt 2 ]]; then
  sed -n '2,20p' "$0" >&2   # mostra o modo de uso
  exit 1
fi
method="$1"; route="$2"; body_file="${3:-}"

if [[ "$route" =~ ^https?:// ]]; then
  url="$route"
else
  require_vars API_BASE_URL
  url="${API_BASE_URL%/}$route"
fi
if [[ -n "$body_file" && ! -f "$body_file" ]]; then
  echo "ERRO: arquivo de corpo não encontrado: $body_file" >&2
  exit 1
fi

hdr_file=$(mktemp); out_file=$(mktemp)
trap 'rm -f "$hdr_file" "$out_file"' EXIT

# Executa a chamada. $1 = token a enviar (vazio = sem autenticação)
do_request() {
  local token="$1"
  local args=(-sS -X "$method" "$url" -H "Accept: application/json" -D "$hdr_file" -o "$out_file" -w "%{http_code} %{time_total}")
  if [[ -n "$body_file" ]]; then
    args+=(-H "Content-Type: application/json" --data-binary "@$body_file")
  fi
  if [[ -n "$token" ]]; then
    args+=(-H "${AUTH_HEADER_NAME:-Authorization}: ${AUTH_SCHEME:-Bearer} $token")
  fi
  curl "${args[@]}" ${extra[@]+"${extra[@]}"}
}

case "$auth_mode" in
  none)   token=""; auth_desc="sem token" ;;
  custom) token="$custom_token"; auth_desc="token informado manualmente" ;;
  auto)   token=$("$(dirname "$0")/get_token.sh"); auth_desc="token do usuário de teste do Bran" ;;
esac

note=""
result=$(do_request "$token")
status="${result%% *}"
if [[ "$auth_mode" == "auto" && "$status" == "401" ]]; then
  token=$("$(dirname "$0")/get_token.sh" --force)
  result=$(do_request "$token")
  status="${result%% *}"
  note=" (a 1ª tentativa deu 401; token renovado e chamada repetida)"
fi
time_total="${result#* }"

echo ">>> $method $url"
echo ">>> Autenticação: $auth_desc"
[[ -n "${extra[*]:-}" ]] && echo ">>> Cabeçalhos extras: ${extra[*]}"
if [[ -n "$body_file" ]]; then
  echo ">>> Corpo ($body_file):"
  jq . "$body_file" 2>/dev/null || cat "$body_file"
fi
echo
echo "<<< Status: $status (${time_total}s)$note"
echo "<<< Headers:"
grep -iE '^(content-type|location|x-request-id|retry-after):' "$hdr_file" | tr -d '\r' || true
echo "<<< Corpo:"
jq . "$out_file" 2>/dev/null || cat "$out_file"
echo
