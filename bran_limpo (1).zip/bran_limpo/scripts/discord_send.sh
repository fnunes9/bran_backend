#!/usr/bin/env bash
# Envia uma mensagem ao Discord como "Bran", sem exibir a URL do webhook.
#
# Uso:
#   scripts/discord_send.sh reprovacao caminho/mensagem.txt
#   scripts/discord_send.sh produto    caminho/mensagem.txt
#
# A mensagem fica num arquivo (evita problemas com aspas e quebras de linha).
# Tenta 2 vezes. Imprime só o status HTTP: 200 ou 204 = enviado.
set -euo pipefail
source "$(dirname "$0")/_load_env.sh"

channel="${1:-}"; msg_file="${2:-}"
case "$channel" in
  reprovacao) var=DISCORD_WEBHOOK_REPROVACAO ;;
  produto)    var=DISCORD_WEBHOOK_PRODUTO ;;
  *) echo "Uso: $0 reprovacao|produto arquivo.txt" >&2; exit 1 ;;
esac
require_vars "$var"
[[ -f "$msg_file" ]] || { echo "ERRO: arquivo não encontrado: $msg_file" >&2; exit 1; }

chars=$(wc -m < "$msg_file")
if (( chars > 2000 )); then
  echo "ERRO: mensagem com $chars caracteres (limite do Discord: 2000). Divida em partes." >&2
  exit 1
fi

# Troca o domínio antigo pelo atual
webhook="${!var/discordapp.com/discord.com}"
payload=$(jq -n --rawfile c "$msg_file" '{username: "Bran", content: $c}')

for attempt in 1 2; do
  status=$(curl -sS -o /dev/null -w "%{http_code}" -X POST "$webhook?wait=true" \
    -H "Content-Type: application/json" --data-binary "$payload" 2>/dev/null || echo "000")
  if [[ "$status" == "200" || "$status" == "204" ]]; then
    echo "Enviado ao canal '$channel' (status $status)."
    exit 0
  fi
  echo "Tentativa $attempt falhou (status $status)." >&2
done
echo "ERRO: envio ao canal '$channel' falhou nas 2 tentativas (status $status)." >&2
exit 1
