#!/usr/bin/env bash
# Executa SQL no MySQL de homolog com a conexão do .env e mostra o resultado em tabela.
#
# Uso:
#   scripts/db_query.sh "SELECT id, status FROM reservas WHERE id = 123;"
#
# Regras (detalhes na skill do Bran):
#   - SQL sempre INLINE, entre aspas (o hook de proteção lê o comando antes de rodar).
#   - SELECT é livre. INSERT/UPDATE/DELETE só se estritamente necessário, com WHERE
#     e SELECT de conferência antes e depois. DROP/TRUNCATE/ALTER são proibidos.
set -euo pipefail
source "$(dirname "$0")/_load_env.sh"
require_vars DB_HOST DB_USER DB_PASSWORD DB_NAME

if [[ $# -ne 1 ]]; then
  echo "Uso: $0 \"<SQL>\"" >&2
  exit 1
fi
if ! command -v mysql >/dev/null; then
  echo "ERRO: cliente mysql não instalado. Ubuntu/Debian: sudo apt install mysql-client" >&2
  exit 1
fi

# A senha vai por um "arquivo" temporário em memória (<(...)), e não na linha de comando,
# para não aparecer na lista de processos nem gerar aviso de senha insegura.
mysql --defaults-extra-file=<(printf '[client]\npassword=%s\n' "$DB_PASSWORD") \
  -h "$DB_HOST" -P "${DB_PORT:-3306}" -u "$DB_USER" "$DB_NAME" \
  --table -e "$1"
