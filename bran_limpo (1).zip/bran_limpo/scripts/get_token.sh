#!/usr/bin/env bash
# Devolve (no stdout) um token válido do usuário de teste do Bran, com cache.
# Evita fazer login a cada chamada: reaproveita o token até ele vencer.
#
# Uso:
#   scripts/get_token.sh           -> usa o cache se ainda for válido
#   scripts/get_token.sh --force   -> ignora o cache e faz login de novo
#
# O login em si fica em config/login.sh (cada API tem o seu jeito).
set -euo pipefail
source "$(dirname "$0")/_load_env.sh"

CACHE_DIR="$BRAN_ROOT/.cache"
CACHE_FILE="$CACHE_DIR/token"
LOGIN_SCRIPT="$BRAN_ROOT/config/login.sh"
MARGIN=60   # renova 60 s antes de vencer, para não usar token "no limite"
now=$(date +%s)

# 1) Tenta o cache: linha 1 = token, linha 2 = vencimento (epoch)
if [[ "${1:-}" != "--force" && -f "$CACHE_FILE" ]]; then
  token=$(sed -n '1p' "$CACHE_FILE")
  exp=$(sed -n '2p' "$CACHE_FILE")
  if [[ -n "$token" && "$exp" =~ ^[0-9]+$ ]] && (( now < exp - MARGIN )); then
    printf '%s' "$token"
    exit 0
  fi
fi

# 2) Faz login
if [[ ! -x "$LOGIN_SCRIPT" ]]; then
  echo "ERRO: $LOGIN_SCRIPT não existe ou não é executável." >&2
  exit 1
fi
token=$("$LOGIN_SCRIPT")
if [[ -z "$token" || "$token" == "null" ]]; then
  echo "ERRO: o login não devolveu token. Confira config/login.sh e as credenciais do .env." >&2
  exit 1
fi

# 3) Descobre o vencimento. JWT = três partes separadas por ponto; a do meio tem o campo "exp".
exp=""
if [[ "$token" =~ ^[^.]+\.[^.]+\.[^.]+$ ]]; then
  payload=$(cut -d. -f2 <<<"$token" | tr '_-' '/+')
  # base64 exige tamanho múltiplo de 4: completa com "="
  while (( ${#payload} % 4 )); do payload+="="; done
  exp=$(base64 -d 2>/dev/null <<<"$payload" | jq -r '.exp // empty' 2>/dev/null || true)
fi
if [[ ! "$exp" =~ ^[0-9]+$ ]]; then
  exp=$(( now + ${TOKEN_TTL_SECONDS:-3600} ))
fi

# 4) Grava o cache só para o seu usuário (permissão 600)
mkdir -p "$CACHE_DIR"
umask 077
printf '%s\n%s\n' "$token" "$exp" > "$CACHE_FILE"
printf '%s' "$token"
