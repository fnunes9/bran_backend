#!/usr/bin/env bash
# Carrega o .env da raiz do Bran. É usado pelos outros scripts (não rodar sozinho).
# Define BRAN_ROOT = pasta raiz do Bran (onde ficam CLAUDE.md e .env).

BRAN_ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"

if [[ ! -f "$BRAN_ROOT/.env" ]]; then
  echo "ERRO: $BRAN_ROOT/.env não existe. Crie com: cp .env.example .env (e preencha)." >&2
  exit 1
fi

# set -a exporta automaticamente todas as variáveis lidas do .env
set -a
# shellcheck disable=SC1091
source "$BRAN_ROOT/.env"
set +a

# Confere se as variáveis indicadas estão preenchidas, sem exibir os valores
require_vars() {
  local missing=()
  for v in "$@"; do
    [[ -n "${!v:-}" ]] || missing+=("$v")
  done
  if (( ${#missing[@]} )); then
    echo "ERRO: variáveis vazias no .env: ${missing[*]}" >&2
    exit 1
  fi
}
