#!/usr/bin/env bash
# Hook de proteção do banco (PreToolUse do Claude Code, ferramenta Bash).
# Roda ANTES de qualquer comando Bash do Claude. Se o comando mexe com MySQL, bloqueia:
#   - DROP, TRUNCATE, ALTER (sempre);
#   - DELETE ou UPDATE sem WHERE.
# Bloquear = sair com código 2; a mensagem do stderr volta para o Claude, que não executa o comando.
#
# Limitação conhecida: o hook só enxerga o texto do comando. Por isso a skill exige o SQL
# inline no scripts/db_query.sh (SQL vindo de arquivo não é inspecionado).

input=$(cat)
cmd=$(jq -r '.tool_input.command // empty' <<<"$input" 2>/dev/null)
[[ -z "$cmd" ]] && exit 0

# Só analisa comandos que chamam o db_query.sh ou o programa mysql
# (ex.: "apt install mysql-client" não conta, porque ali "mysql" é parte de outra palavra)
if ! grep -qiE '(db_query\.sh|(^|[;&|[:space:]])mysql([[:space:]]|$))' <<<"$cmd"; then
  exit 0
fi

block() {
  echo "BLOQUEADO pelo hook de proteção do banco: $1" >&2
  echo "Regras: DROP/TRUNCATE/ALTER são proibidos; DELETE/UPDATE só com WHERE e SELECT de conferência antes e depois." >&2
  exit 2
}

# Junta as linhas e separa por ";" para analisar cada instrução SQL
flat=$(tr '\n' ' ' <<<"$cmd")

if grep -qiE '\b(DROP|TRUNCATE|ALTER)\b' <<<"$flat"; then
  block "comando contém DROP, TRUNCATE ou ALTER."
fi

while IFS= read -r stmt; do
  if grep -qiE '\b(DELETE|UPDATE)\b' <<<"$stmt" && ! grep -qiE '\bWHERE\b' <<<"$stmt"; then
    block "DELETE/UPDATE sem WHERE: $(sed 's/^ *//' <<<"$stmt" | cut -c1-200)"
  fi
done < <(tr ';' '\n' <<<"$flat")

exit 0
