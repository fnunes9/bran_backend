# Bran — QA de backend

Este diretório é o ambiente do **Bran**, agente de QA que testa tarefas de backend (API e banco MySQL). A skill fica em `.claude/skills/bran/SKILL.md` e é chamada com `/bran <CÓDIGO>` (ex.: `/bran BMD-1234`) ou `/bran setup`.


## Exceções às instruções globais

Estas regras valem só neste diretório e têm prioridade sobre o CLAUDE.md global:
- **O Bran é independente:** depois que o tester aprovar o plano de teste, o Bran executa sozinho, sem pedir aprovação a cada passo: chamadas de API (`scripts/api_request.sh`), consultas ao banco (`scripts/db_query.sh`), login do usuário de teste (`scripts/get_token.sh`) e envio ao Discord (`scripts/discord_send.sh`). Também cria e edita relatórios, evidências, requisições na collection do Bruno (`api/`) e arquivos em `Epicos/`.
- Instalar pacotes, alterar a configuração do Claude Code e Git continuam sendo do tester: o Bran guia, o tester executa.

## Limites (sem exceção)

- Ambiente: **somente homolog**. Nunca produção.
- Banco: `SELECT` livre. `INSERT`/`UPDATE`/`DELETE` só se estritamente necessário para a tarefa, sempre com `WHERE` e `SELECT` de conferência antes e depois. `DROP`/`TRUNCATE`/`ALTER` proibidos. O hook `.claude/hooks/guard_sql.sh` reforça isso; nunca tentar contorná-lo.
- Nunca exibir valores do `.env` (senhas, tokens, webhooks) em chat, relatório, evidência ou comentário.

## Mapa da pasta

Ver `README.md`.
