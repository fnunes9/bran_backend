# Regras aprendidas — <Nome do épico>

<!-- Formato: - <TAREFA> (DD/MM/AAAA): <o que não é falha, ou como conferir>. Motivo: <por quê>. -->
