#!/usr/bin/env bash
# Faz login na API com o usuário de teste do Bran e imprime SÓ o token.
# Quem chama este script é o scripts/get_token.sh (que cuida do cache).
#
# >>> AINDA NÃO CONFIGURADO <<<
# Para configurar, troque o bloco de exemplo abaixo pelo curl de login real da sua API:
#   - use as variáveis do .env ($API_BASE_URL, $BRAN_USER, $BRAN_PASSWORD), nunca valores fixos;
#   - termine com um filtro jq que extraia o token da resposta (ex.: jq -r '.token').
set -euo pipefail
source "$(dirname "$0")/../scripts/_load_env.sh"
require_vars API_BASE_URL BRAN_USER BRAN_PASSWORD

echo "ERRO: config/login.sh ainda não foi configurado com o login da sua API." >&2
exit 1

# ----- Exemplo (ajustar rota, corpo e caminho do token) -----
# body=$(jq -n --arg u "$BRAN_USER" --arg p "$BRAN_PASSWORD" '{email: $u, password: $p}')
# curl -sS -X POST "$API_BASE_URL/ROTA/DE/LOGIN" \
#   -H "Content-Type: application/json" \
#   --data-binary "$body" \
#   | jq -r '.CAMINHO.DO.TOKEN'
