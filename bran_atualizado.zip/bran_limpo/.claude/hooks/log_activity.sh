#!/usr/bin/env bash
# Hook de log (PostToolUse do Claude Code): registra cada ação do Bran em .cache/bran.log,
# para acompanhar ao vivo num terminal com:
#   tail -f ~/Documentos/Bran/.cache/bran.log
#
# Segredos (senhas, chaves, webhooks, tokens) são mascarados antes de gravar.
# Este hook nunca bloqueia nada: sempre termina com sucesso.

ROOT="${CLAUDE_PROJECT_DIR:-$(cd "$(dirname "$0")/../.." && pwd)}"
LOG="$ROOT/.cache/bran.log"
mkdir -p "$ROOT/.cache"

input=$(cat)
tool=$(jq -r '.tool_name // "?"' <<<"$input" 2>/dev/null)
ts=$(date '+%H:%M:%S')

# --- Lista de segredos a mascarar (valores do .env e tokens em cache) ---
secrets=()
if [[ -f "$ROOT/.env" ]]; then
  while IFS='=' read -r key val; do
    [[ "$key" =~ (PASSWORD|WEBHOOK|API_KEY|TOKEN)$ || "$key" =~ _HEADERS$ ]] || continue
    val="${val#\'}"; val="${val%\'}"; val="${val#\"}"; val="${val%\"}"
    if [[ "$key" =~ _HEADERS$ ]]; then
      IFS='|' read -ra hs <<<"$val"
      for h in "${hs[@]}"; do v="${h#*: }"; [[ ${#v} -ge 6 ]] && secrets+=("$v"); done
    elif [[ ${#val} -ge 6 ]]; then
      secrets+=("$val")
    fi
  done < <(grep -E '^[A-Z0-9_]+=' "$ROOT/.env")
fi
for f in "$ROOT"/.cache/token_*.json; do
  [[ -f "$f" ]] || continue
  for v in $(jq -r '.token, .session' "$f" 2>/dev/null); do [[ ${#v} -ge 6 ]] && secrets+=("$v"); done
done

mask() {
  local s="$1"
  for v in "${secrets[@]}"; do s="${s//"$v"/***}"; done
  # Qualquer JWT que sobrar (eyJ...)
  sed -E 's/eyJ[A-Za-z0-9_-]{10,}\.[A-Za-z0-9._-]+/***JWT***/g' <<<"$s"
}

{
  case "$tool" in
    Bash)
      desc=$(jq -r '.tool_input.description // ""' <<<"$input")
      cmd=$(jq -r '.tool_input.command // ""' <<<"$input")
      out=$(jq -r '.tool_response.stdout // .tool_response.output // (.tool_response | tostring)' <<<"$input" 2>/dev/null)
      echo "[$ts] ▶ $desc"
      mask "$cmd" | head -5 | sed 's/^/    $ /'
      mask "$out" | head -12 | sed 's/^/    │ /'
      ;;
    Write|Edit|Read)
      echo "[$ts] $tool — $(jq -r '.tool_input.file_path // ""' <<<"$input" | sed "s|$ROOT/||")"
      ;;
    mcp__*)
      args=$(jq -c '.tool_input' <<<"$input" | cut -c1-200)
      echo "[$ts] Kanban: ${tool#mcp__} $(mask "$args")"
      ;;
    *)
      echo "[$ts] $tool"
      ;;
  esac
  echo
} >> "$LOG" 2>/dev/null

exit 0
