#!/usr/bin/env bash
# Devolve (no stdout) um token válido de um PERFIL de usuário de teste, com cache.
# Evita fazer login a cada chamada: reaproveita o token até ele vencer.
#
# Uso:
#   scripts/get_token.sh PERFIL              -> token de acesso (usa o cache se ainda for válido)
#   scripts/get_token.sh PERFIL --session    -> token de sessão (ex.: session-authorization)
#   scripts/get_token.sh PERFIL --force      -> ignora o cache e faz login de novo
# Sem PERFIL, usa DEFAULT_PERFIL do .env.
#
# O login em si fica em config/login.sh (cada API tem o seu jeito).
set -euo pipefail
source "$(dirname "$0")/_load_env.sh"

perfil=""; force=0; field="token"
for arg in "$@"; do
  case "$arg" in
    --force)   force=1 ;;
    --session) field="session" ;;
    *)         perfil="$arg" ;;
  esac
done
perfil="${perfil:-${DEFAULT_PERFIL:-}}"
[[ -n "$perfil" ]] || { echo "ERRO: informe o PERFIL ou defina DEFAULT_PERFIL no .env." >&2; exit 1; }

CACHE_DIR="$BRAN_ROOT/.cache"
CACHE_FILE="$CACHE_DIR/token_${perfil}.json"
LOGIN_SCRIPT="$BRAN_ROOT/config/login.sh"
MARGIN=60   # renova 60 s antes de vencer, para não usar token "no limite"
now=$(date +%s)

valid_cache() {
  [[ -f "$CACHE_FILE" ]] || return 1
  local exp; exp=$(jq -r '.exp // 0' "$CACHE_FILE" 2>/dev/null || echo 0)
  [[ "$exp" =~ ^[0-9]+$ ]] && (( now < exp - MARGIN ))
}

if (( force )) || ! valid_cache; then
  [[ -x "$LOGIN_SCRIPT" ]] || { echo "ERRO: $LOGIN_SCRIPT não existe ou não é executável." >&2; exit 1; }
  resp=$("$LOGIN_SCRIPT" "$perfil")
  token=$(jq -r "${TOKEN_JSON_PATH:-.token} // empty" <<<"$resp")
  session=""
  [[ -n "${SESSION_JSON_PATH:-}" ]] && session=$(jq -r "${SESSION_JSON_PATH} // empty" <<<"$resp")
  if [[ -z "$token" ]]; then
    echo "ERRO: a resposta do login não tem token em ${TOKEN_JSON_PATH:-.token}. Campos recebidos: $(jq -c 'keys' <<<"$resp" 2>/dev/null)" >&2
    exit 1
  fi

  # Vencimento: JWT = três partes separadas por ponto; a do meio tem o campo "exp"
  exp=""
  if [[ "$token" =~ ^[^.]+\.[^.]+\.[^.]+$ ]]; then
    payload=$(cut -d. -f2 <<<"$token" | tr '_-' '/+')
    while (( ${#payload} % 4 )); do payload+="="; done   # base64 exige múltiplo de 4
    exp=$(base64 -d 2>/dev/null <<<"$payload" | jq -r '.exp // empty' 2>/dev/null || true)
  fi
  [[ "$exp" =~ ^[0-9]+$ ]] || exp=$(( now + ${TOKEN_TTL_SECONDS:-3600} ))

  # Grava o cache só para o seu usuário
  mkdir -p "$CACHE_DIR"; umask 077
  jq -n --arg t "$token" --arg s "$session" --argjson e "$exp" '{token: $t, session: $s, exp: $e}' > "$CACHE_FILE"
fi

jq -r ".$field // empty" "$CACHE_FILE" | tr -d '\n'
