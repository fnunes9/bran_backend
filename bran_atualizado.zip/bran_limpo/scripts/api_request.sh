#!/usr/bin/env bash
# Faz uma chamada à API de homolog e mostra requisição, status, headers e corpo da resposta.
# Token, token de sessão e cabeçalhos fixos do perfil são colocados automaticamente (e nunca exibidos).
#
# Uso:
#   scripts/api_request.sh [opções] MÉTODO ROTA [arquivo_corpo.json]
#
# Opções (antes do método):
#   --perfil NOME      perfil de login do .env (ex.: PRO_ADMIN). Padrão: DEFAULT_PERFIL
#   --sem-token        não envia token nem sessão (testar 401); mantém os cabeçalhos fixos do perfil
#   --token VALOR      envia este token no lugar do token do perfil (testar token inválido)
#   -H "Nome: valor"   cabeçalho extra; se tiver o mesmo nome de um cabeçalho fixo do perfil,
#                      substitui o do perfil (ex.: outro x-api-key). Pode repetir.
#
# Exemplos:
#   scripts/api_request.sh --perfil PRO_ADMIN GET /v2/admin/algo
#   scripts/api_request.sh --perfil PRO_BUSCADOR POST /v2/rota evidencias/CT01_corpo.json
#   scripts/api_request.sh --perfil PRO_ADMIN --sem-token GET /v2/admin/algo
#
# ROTA pode ser só o caminho (/v2/...) ou uma URL completa (https://...).
# Se a resposta for 401 com o token do perfil, renova o token UMA vez e repete.
set -euo pipefail
source "$(dirname "$0")/_load_env.sh"

perfil="${DEFAULT_PERFIL:-}"; auth_mode="auto"; custom_token=""; extra=()
while [[ $# -gt 0 ]]; do
  case "$1" in
    --perfil)    perfil="${2:-}"; shift 2 ;;
    --sem-token) auth_mode="none"; shift ;;
    --token)     auth_mode="custom"; custom_token="${2:-}"; shift 2 ;;
    -H)          extra+=("$2"); shift 2 ;;
    *) break ;;
  esac
done

if [[ $# -lt 2 ]]; then
  sed -n '2,22p' "$0" >&2   # mostra o modo de uso
  exit 1
fi
method="$1"; route="$2"; body_file="${3:-}"

if [[ "$route" =~ ^https?:// ]]; then
  url="$route"
else
  require_vars API_BASE_URL
  url="${API_BASE_URL%/}$route"
fi
if [[ -n "$body_file" && ! -f "$body_file" ]]; then
  echo "ERRO: arquivo de corpo não encontrado: $body_file" >&2
  exit 1
fi

# Cabeçalhos: fixos do perfil + extras (o extra com o mesmo nome substitui o do perfil)
declare -A override=()
for h in ${extra[@]+"${extra[@]}"}; do override["$(cut -d: -f1 <<<"$h" | tr '[:upper:]' '[:lower:]')"]=1; done
headers=(-H "Accept: application/json")
profile_names=()
if [[ -n "$perfil" ]]; then
  hdr_var="${perfil}_HEADERS"
  IFS='|' read -ra fixed <<<"${!hdr_var:-}"
  for h in "${fixed[@]}"; do
    [[ -z "$h" ]] && continue
    name=$(cut -d: -f1 <<<"$h" | tr '[:upper:]' '[:lower:]')
    [[ -n "${override[$name]:-}" ]] && continue
    headers+=(-H "$h"); profile_names+=("$name")
  done
fi
for h in ${extra[@]+"${extra[@]}"}; do headers+=(-H "$h"); done

hdr_file=$(mktemp); out_file=$(mktemp)
trap 'rm -f "$hdr_file" "$out_file"' EXIT

# Executa a chamada. $1 = token, $2 = token de sessão (vazios = não envia)
do_request() {
  local token="$1" session="$2"
  local args=(-sS -X "$method" "$url" -D "$hdr_file" -o "$out_file" -w "%{http_code} %{time_total}" "${headers[@]}")
  [[ -n "$body_file" ]] && args+=(-H "Content-Type: application/json" --data-binary "@$body_file")
  [[ -n "$token" ]] && args+=(-H "${AUTH_HEADER_NAME:-Authorization}: ${AUTH_SCHEME:-Bearer} $token")
  [[ -n "$session" && -n "${SESSION_HEADER_NAME:-}" ]] && args+=(-H "${SESSION_HEADER_NAME}: $session")
  curl "${args[@]}"
}

get_token() { "$(dirname "$0")/get_token.sh" "$perfil" "$@"; }

token=""; session=""
case "$auth_mode" in
  none)   auth_desc="sem token e sem sessão" ;;
  custom) token="$custom_token"; auth_desc="token informado manualmente (sem sessão)" ;;
  auto)
    [[ -n "$perfil" ]] || { echo "ERRO: informe --perfil ou defina DEFAULT_PERFIL no .env." >&2; exit 1; }
    token=$(get_token); session=$(get_token --session)
    auth_desc="token e sessão do perfil $perfil" ;;
esac

note=""
result=$(do_request "$token" "$session")
status="${result%% *}"
if [[ "$auth_mode" == "auto" && "$status" == "401" ]]; then
  token=$(get_token --force); session=$(get_token --session)
  result=$(do_request "$token" "$session")
  status="${result%% *}"
  note=" (a 1ª tentativa deu 401; token renovado e chamada repetida)"
fi
time_total="${result#* }"

echo ">>> $method $url"
echo ">>> Perfil: ${perfil:-nenhum} · Autenticação: $auth_desc"
(( ${#profile_names[@]} )) && echo ">>> Cabeçalhos do perfil: ${profile_names[*]} (valores ocultos)"
(( ${#extra[@]} )) && echo ">>> Cabeçalhos extras: $(printf '%s; ' "${extra[@]}")"
if [[ -n "$body_file" ]]; then
  echo ">>> Corpo ($body_file):"
  jq . "$body_file" 2>/dev/null || cat "$body_file"
fi
echo
echo "<<< Status: $status (${time_total}s)$note"
echo "<<< Headers:"
grep -iE '^(content-type|location|x-request-id|retry-after):' "$hdr_file" | tr -d '\r' || true
echo "<<< Corpo:"
jq . "$out_file" 2>/dev/null || cat "$out_file"
echo
