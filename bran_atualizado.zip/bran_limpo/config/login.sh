#!/usr/bin/env bash
# Faz login na API com o usuário de teste de um PERFIL e imprime a resposta JSON do login.
# Quem chama este script é o scripts/get_token.sh, que extrai os tokens (TOKEN_JSON_PATH e
# SESSION_JSON_PATH do .env) e cuida do cache.
#
# Uso: config/login.sh PERFIL      (ex.: config/login.sh ADMIN)
#
# >>> PERSONALIZE <<< Cada API faz login de um jeito. Ajuste o corpo de cada <PERFIL>_LOGIN_TYPE
# abaixo a partir do curl de login da sua API (sem colar senha: use as variáveis do .env).
# Se não souber, peça ajuda ao Bran (/bran setup) entregando o curl com a senha trocada por SENHA_AQUI.
set -euo pipefail
source "$(dirname "$0")/../scripts/_load_env.sh"

perfil="${1:?Uso: config/login.sh PERFIL}"
require_vars API_BASE_URL "${perfil}_LOGIN_TYPE" "${perfil}_LOGIN_ROUTE" "${perfil}_USER" "${perfil}_PASSWORD"

type_var="${perfil}_LOGIN_TYPE"; route_var="${perfil}_LOGIN_ROUTE"
user_var="${perfil}_USER"; pass_var="${perfil}_PASSWORD"; hdr_var="${perfil}_HEADERS"

# Corpo do login por tipo (exemplo: {"email": ..., "password": ...})
case "${!type_var}" in
  padrao) body=$(jq -n --arg u "${!user_var}" --arg p "${!pass_var}" '{email: $u, password: $p}') ;;
  *) echo "ERRO: ${type_var} '${!type_var}' não tratado em config/login.sh." >&2; exit 1 ;;
esac

headers=(-H "accept: application/json" -H "content-type: application/json")
IFS='|' read -ra fixed <<<"${!hdr_var:-}"
for h in "${fixed[@]}"; do [[ -n "$h" ]] && headers+=(-H "$h"); done

out=$(mktemp); trap 'rm -f "$out"' EXIT
status=$(curl -sS -o "$out" -w '%{http_code}' -X POST "${API_BASE_URL%/}${!route_var}" "${headers[@]}" --data-binary "$body")

if [[ ! "$status" =~ ^2 ]]; then
  echo "ERRO: login do perfil $perfil falhou (status $status): $(jq -c '.message // .error // .' "$out" 2>/dev/null | cut -c1-300)" >&2
  exit 1
fi
cat "$out"
