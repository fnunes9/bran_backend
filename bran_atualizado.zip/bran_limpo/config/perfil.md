# Perfil do tester

Este arquivo diz ao Bran **quem usa** e **como integrar com o kanban**. A skill (`.claude/skills/bran/SKILL.md`) é genérica; o que é específico de cada pessoa ou empresa fica aqui.

> Não sabe preencher? Abra o Claude Code nesta pasta e rode `/bran setup`. O Bran faz as perguntas e preenche junto com você.

## Tester

- Nome:
- Empresa:

## Kanban

- Ferramenta: <Maestro / Jira / Linear / Trello / outra>
- Conexão: <URL do servidor MCP e tipo de autenticação: token ou login no navegador>
- Ferramentas (prefixo `mcp__<nome>__`):
  - buscar tarefa pelo código:
  - comentar:
  - criar revisão:
  - resolver revisão:
  - responder revisão:
  - mover tarefa:
- Como se identifica uma tarefa: <ex.: ABC-1234>
- Colunas:
  - Em Testes:
  - Pronto para subir (aprovada):
  - Precisam de Ajustes (reprovada):
- Tem revisões separadas dos comentários: <sim / não (cada revisão vira um comentário)>
- Classificação das revisões (como se chama em cada ferramenta):
  - Sucesso:
  - Erro no desenvolvimento:
  - Erro no planejamento:
  - Erro no teste:
  - Sem classificação:

## Perfis de login (`--perfil` no api_request.sh)

| Perfil | Quem é | Tipo de login | Observação |
|---|---|---|---|
| `ADMIN` | <ex.: administrador do sistema X> | `padrao` | |

Cabeçalhos que variam por área da API (ex.: `x-api-key` diferente por módulo): listar aqui a área e onde achar o valor (nunca o valor em si).

## Banco e VPN

- O banco exige VPN? <sim/não>. Se sim: comando para conferir, comando para conectar e o que o tester precisa fazer.

## Sistemas

- URL base da API de homolog: no `.env` (`API_BASE_URL`). Se houver mais de uma API, liste aqui o nome de cada uma e a variável do `.env` correspondente.
